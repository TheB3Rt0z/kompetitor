*em **strong em***

***strong em** em*

*em **strong em** em*

_em __strong em___

___strong em__ em_

_em __strong em__ em_