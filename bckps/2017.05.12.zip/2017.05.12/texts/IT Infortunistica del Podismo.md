Infortunistica del Podismo
==========================

Ginocchio
---------
- sindrome femoro-rotulea o della bandelletta ileotibiale detta anche ginocchio del corridore:
- tendinite del popliteo

Coscia
------
- lesione dei flessori (hamstrings, muscoli posteriori):
- pubalgia (coscia alta): La pubalgia è una tendinopatia inserzionale di natura infiammatoria che interessa le inserzioni (mioentesite) dei muscoli adduttori della coscia per sovraccarico funzionale o microtraumi ripetuti -> https://it.wikipedia.org/wiki/Pubalgia
- sindrome del piriforme:

Piede
-----
- tendinopatia dell'achilleo o tendine d'achille:
- pariostite o fascite tibiale (caviglia alta):
- fascite plantare o spina calcaneare:
- tallonite o dolore sotto-calcaneare:

Schiena
-------
- lombalgia (mal di schiena bassa):

Generale
--------
- fratture e/o microfratture da stress:
- lesioni muscolari sparse (stiramenti, contratture etc.):

Risorse
-------
http://studioronconi.com/news/instabilita--della-caviglia.htm
http://www.noene-italia.com/tallonite/
http://www.noene-italia.com/tendinite-del-popliteo/
http://www.noene-italia.com/ginocchio/
http://www.noene-italia.com/periostite-tibiale/
http://www.noene-italia.com/sindrome-del-piriforme/
http://www.noene-italia.com/pubalgia-del-podista/